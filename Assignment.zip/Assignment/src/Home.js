import React from 'react'

const Home = () => {
  return (
    <div><svg></svg>
    <button>Random</button></div>
  )
}

export default Home